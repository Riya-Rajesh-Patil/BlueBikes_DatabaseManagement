import streamlit as st
from PIL import Image

st.title('Blue Bikes Database Management System')
# st.write('')
st.image('bluebikes.jpg')
